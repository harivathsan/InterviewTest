declare interface IStyles {
  quiz: string;
  quizInner: string;
  topCarousel: string;
  carouselImage: string;
  carouselCaption: string;
  questionBadge: string;
  questionTitle: string;
  questionCount: string;
  scenario: string;
  instruction: string;
  headerRow: string;
  optionsGrid: string;
  optionCol: string;
  optionCard: string;
  optionImageWrap: string;
  optionImage: string;
  optionLabel: string;
  optionCheck: string;
  submitWrap: string;
  submitButton: string;
}
declare const styles: IStyles;
export default styles;