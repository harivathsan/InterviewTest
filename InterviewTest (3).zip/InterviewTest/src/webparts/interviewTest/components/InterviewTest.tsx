import * as React from 'react';
import { Container, Button, Form, Carousel } from 'react-bootstrap';
import styles from './InterviewTest.module.scss';
import type { IInterviewTestProps } from './IInterviewTestProps';
import ModernElearning from '../assets/ModernElearning.jpg';
import ELearning from '../assets/ELearning.jpg';
import Learning from '../assets/Learning.jpg';
import Laptop from '../assets/Laptop.jpg';

interface IOption {
  id: string;
  image: string;
  label?: string;
}

interface ISlide {
  id: string;
  image: string;
  caption: string;
}

interface IInterviewTestState {
  selected: string[];
}

const options: IOption[] = [
  { id: 'opt1', image: ModernElearning, label: 'Learning' },
  { id: 'opt2', image: ELearning, label: 'Complex eLearning' },
  { id: 'opt3', image: Learning, label: 'eLearning' },
  { id: 'opt4', image: Laptop, label: 'Medium Complexity eLearning' }
];

const slides: ISlide[] = [
  { id: 'slide1', image: ModernElearning, caption: 'Modern eLearning' },
  { id: 'slide2', image: ELearning, caption: 'Complex eLearning' },
  { id: 'slide3', image: Learning, caption: 'eLearning' },
  { id: 'slide4', image: Laptop, caption: 'Medium Complexity eLearning' }
];

export default class InterviewTest extends React.Component<IInterviewTestProps, IInterviewTestState> {
  constructor(props: IInterviewTestProps) {
    super(props);
    this.state = { selected: [] };
  }

  private readonly toggleOption = (id: string): void => {
    this.setState(prev => ({
      selected: prev.selected.indexOf(id) !== -1
        ? prev.selected.filter(value => value !== id)
        : [...prev.selected, id]
    }));
  };

  public render(): React.ReactElement<IInterviewTestProps> {
    const { selected } = this.state;
    const hasSelection = selected.length > 0;

    return (
      <div className={styles.quiz}>
        <Container fluid className={styles.quizInner}>
          <Carousel className={styles.topCarousel} interval={4000} fade>
            {slides.map(slide => (
              <Carousel.Item key={slide.id}>
                <img className={styles.carouselImage} src={slide.image} alt={slide.caption} />
                <Carousel.Caption>
                  <h5 className={styles.carouselCaption}>{slide.caption}</h5>
                </Carousel.Caption>
              </Carousel.Item>
            ))}
          </Carousel>

          <div className={styles.headerRow}>
            <div className={styles.questionBadge}>
              <span className={styles.questionTitle}>Question</span>
              <span className={styles.questionCount}>01/02</span>
            </div>

            <section className={styles.scenario}>
              <p>
                Below are three options on how to respond to the scenario above. Image question the
                client side pings you and tells that they have a personal emergency and will need to be
                away from work.
              </p>
              <p>You will ...</p>
            </section>
          </div>

          <p className={styles.instruction}>
            Below are three options on how to respond to the scenario above. Please choose the
            response that resonates most with you and click <strong>Next</strong> to proceed.
          </p>

          <div className={styles.optionsGrid}>
            {options.map(option => (
              <div key={option.id} className={styles.optionCol}>
                <div className={styles.optionCard}>
                  <div className={styles.optionImageWrap}>
                    <img className={styles.optionImage} src={option.image} alt={option.label ?? ''} />
                    {option.label && <span className={styles.optionLabel}>{option.label}</span>}
                  </div>
                  <Form.Check
                    type="checkbox"
                    aria-label={option.label ?? option.id}
                    className={styles.optionCheck}
                    checked={selected.indexOf(option.id) !== -1}
                    onChange={() => this.toggleOption(option.id)}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className={styles.submitWrap}>
            <Button className={styles.submitButton} disabled={!hasSelection}>
              Submit
            </Button>
          </div>
        </Container>
      </div>
    );
  }
}
